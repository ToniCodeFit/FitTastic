
import { useState, useEffect, useRef, useCallback } from "react";

// ── Liquid Glass helper ──────────────────────────────────────────────
const glass = (extra = "") =>
  `backdrop-blur-xl bg-white/10 border border-white/20 shadow-2xl ${extra}`;
const glassDark = (extra = "") =>
  `backdrop-blur-xl bg-black/20 border border-white/10 shadow-2xl ${extra}`;

// ── Workout library ──────────────────────────────────────────────────
const WORKOUTS = {
  chest: [
    { name: "Push-Ups", duration: 60, type: "exercise" },
    { name: "Pause", duration: 20, type: "rest" },
    { name: "Wide Push-Ups", duration: 60, type: "exercise" },
    { name: "Pause", duration: 20, type: "rest" },
    { name: "Diamond Push-Ups", duration: 60, type: "exercise" },
  ],
  legs: [
    { name: "Squats", duration: 60, type: "exercise" },
    { name: "Pause", duration: 20, type: "rest" },
    { name: "Lunges", duration: 60, type: "exercise" },
    { name: "Pause", duration: 20, type: "rest" },
    { name: "Calf Raises", duration: 60, type: "exercise" },
  ],
  core: [
    { name: "Plank", duration: 60, type: "exercise" },
    { name: "Pause", duration: 20, type: "rest" },
    { name: "Crunches", duration: 60, type: "exercise" },
    { name: "Pause", duration: 20, type: "rest" },
    { name: "Leg Raises", duration: 60, type: "exercise" },
  ],
  arms: [
    { name: "Bicep Curls (Bodyweight)", duration: 60, type: "exercise" },
    { name: "Pause", duration: 20, type: "rest" },
    { name: "Tricep Dips", duration: 60, type: "exercise" },
    { name: "Pause", duration: 20, type: "rest" },
    { name: "Shoulder Press", duration: 60, type: "exercise" },
  ],
  back: [
    { name: "Superman Hold", duration: 60, type: "exercise" },
    { name: "Pause", duration: 20, type: "rest" },
    { name: "Reverse Snow Angels", duration: 60, type: "exercise" },
    { name: "Pause", duration: 20, type: "rest" },
    { name: "Bird-Dog", duration: 60, type: "exercise" },
  ],
};

// ── Seed data for global chat ────────────────────────────────────────
const SEED_CHAT = [
  { id: "sys1", user: "FitBot", text: "Willkommen im FitTastic Chat! 💪", ts: Date.now() - 3600000 },
  { id: "sys2", user: "max_98", text: "Hey alle! Wer macht heute Beine?", ts: Date.now() - 1800000 },
  { id: "sys3", user: "lena_fit", text: "Ich! Gerade meinen Streak auf 7 Tage gebracht 🔥", ts: Date.now() - 900000 },
];

// ── AI Chat helper ───────────────────────────────────────────────────
async function askAI(question, context) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 300,
      messages: [
        {
          role: "user",
          content: `Du bist ein freundlicher Fitness-Coach in der FitTastic App. Kontext: ${context}. Frage: ${question}. Antworte kurz und motivierend auf Deutsch.`,
        },
      ],
    }),
  });
  const data = await res.json();
  return data.content?.[0]?.text || "Ich bin gerade offline. Versuche es später!";
}

async function getFeedback(stats) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 250,
      messages: [
        {
          role: "user",
          content: `Analysiere diese FitTastic-Statistiken und gib ein kurzes, motivierendes Feedback auf Deutsch (3-4 Sätze, mit Emojis): Streak: ${stats.streak} Tage, abgeschlossene Workouts: ${stats.totalWorkouts}, Lieblingsbereich: ${stats.favArea || "unbekannt"}, Tickets verbraucht: ${stats.ticketsUsed}`,
        },
      ],
    }),
  });
  const data = await res.json();
  return data.content?.[0]?.text || "Weiter so! Du machst das super! 💪";
}

// ── Utility ──────────────────────────────────────────────────────────
const genId = () => Math.random().toString(36).slice(2, 8).toUpperCase();
const today = () => new Date().toDateString();
const getDaysInMonth = (y, m) => new Date(y, m + 1, 0).getDate();

// ═══════════════════════════════════════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════════════════════════════════════
export default function FitTastic() {
  // ── Theme ──
  const [dark, setDark] = useState(true);

  // ── Auth ──
  const [screen, setScreen] = useState("login"); // login | register | app
  const [email, setEmail] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regName, setRegName] = useState("");
  const [authError, setAuthError] = useState("");

  // ── User data ──
  const [user, setUser] = useState(null);
  const [users, setUsers] = useState(() => {
    try { return JSON.parse(localStorage.getItem("ft_users") || "{}"); } catch { return {}; }
  });

  const saveUsers = (u) => { setUsers(u); localStorage.setItem("ft_users", JSON.stringify(u)); };

  // ── Tab ──
  const [tab, setTab] = useState("workout");

  // ── Workout prefs ──
  const [showPrefs, setShowPrefs] = useState(false);
  const [prefs, setPrefs] = useState({ areas: ["chest"], durationMin: 5, daysPerWeek: 3 });

  // ── Calendar ──
  const now = new Date();
  const [calYear, setCalYear] = useState(now.getFullYear());
  const [calMonth, setCalMonth] = useState(now.getMonth());

  // ── Active workout ──
  const [workoutActive, setWorkoutActive] = useState(false);
  const [wSteps, setWSteps] = useState([]);
  const [wIdx, setWIdx] = useState(0);
  const [wTimer, setWTimer] = useState(0);
  const [wPaused, setWPaused] = useState(false);
  const timerRef = useRef(null);

  // ── AI ──
  const [aiOpen, setAiOpen] = useState(false);
  const [aiQ, setAiQ] = useState("");
  const [aiA, setAiA] = useState("");
  const [aiLoading, setAiLoading] = useState(false);

  // ── Feedback ──
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [feedbackText, setFeedbackText] = useState("");
  const [feedbackLoading, setFeedbackLoading] = useState(false);

  // ── Friends ──
  const [friendId, setFriendId] = useState("");
  const [friendError, setFriendError] = useState("");
  const [viewingFriend, setViewingFriend] = useState(null);

  // ── Chat ──
  const [chatMsg, setChatMsg] = useState("");
  const [chatMsgs, setChatMsgs] = useState(SEED_CHAT);
  const chatEndRef = useRef(null);

  // ── Settings ──
  const [editName, setEditName] = useState("");
  const [privacyPublic, setPrivacyPublic] = useState(true);
  const [followId, setFollowId] = useState("");

  // ── Tickets reset at midnight ──
  useEffect(() => {
    if (!user) return;
    const lastReset = user.lastTicketReset;
    if (lastReset !== today()) {
      updateUser({ tickets: 2, ticketsUsed: (user.ticketsUsed || 0), lastTicketReset: today() });
    }
  }, [user?.lastTicketReset]);

  // ── Timer logic ──
  useEffect(() => {
    if (workoutActive && !wPaused) {
      timerRef.current = setInterval(() => {
        setWTimer((t) => {
          if (t <= 1) {
            // next step
            setWIdx((i) => {
              const next = i + 1;
              if (next >= wSteps.length) {
                // finished
                clearInterval(timerRef.current);
                setWorkoutActive(false);
                finishWorkout();
                return i;
              }
              setWTimer(wSteps[next]?.duration || 60);
              return next;
            });
            return 0;
          }
          return t - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timerRef.current);
  }, [workoutActive, wPaused, wSteps]);

  // ── Scroll chat ──
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMsgs]);

  // ── Helpers ──
  const updateUser = (patch) => {
    const updated = { ...user, ...patch };
    setUser(updated);
    const u2 = { ...users, [user.email]: updated };
    saveUsers(u2);
  };

  const finishWorkout = () => {
    const area = prefs.areas[0] || "chest";
    const completed = [...(user.completedDays || []), today()];
    const unique = [...new Set(completed)];
    const streak = calcStreak(unique);
    const totalWorkouts = (user.totalWorkouts || 0) + 1;
    updateUser({
      completedDays: unique,
      streak,
      totalWorkouts,
      tickets: Math.max((user.tickets ?? 2) - 0, 0), // already deducted
      favArea: area,
    });
  };

  const calcStreak = (days) => {
    if (!days.length) return 0;
    const sorted = days.map((d) => new Date(d).getTime()).sort((a, b) => b - a);
    let streak = 0;
    let cur = new Date();
    cur.setHours(0, 0, 0, 0);
    for (let d of sorted) {
      const dd = new Date(d);
      dd.setHours(0, 0, 0, 0);
      const diff = (cur - dd) / 86400000;
      if (diff <= 1) { streak++; cur = dd; }
      else break;
    }
    return streak;
  };

  const startWorkout = () => {
    if (!user) return;
    if ((user.tickets ?? 2) <= 0) {
      alert("Keine Tickets mehr! Um Mitternacht gibt es neue. 🎟️");
      return;
    }
    const area = prefs.areas[Math.floor(Math.random() * prefs.areas.length)];
    const steps = WORKOUTS[area] || WORKOUTS.chest;
    setWSteps(steps);
    setWIdx(0);
    setWTimer(steps[0].duration);
    setWPaused(false);
    setWorkoutActive(true);
    updateUser({ tickets: Math.max((user.tickets ?? 2) - 1, 0), ticketsUsed: (user.ticketsUsed || 0) + 1 });
  };

  const stopWorkout = () => {
    clearInterval(timerRef.current);
    setWorkoutActive(false);
    setWIdx(0);
  };

  // ── Auth ──
  const handleLogin = () => {
    setAuthError("");
    const u = users[email];
    if (!u) { setAuthError("Kein Konto mit dieser E-Mail gefunden."); return; }
    setUser(u);
    setScreen("app");
  };

  const handleRegister = () => {
    setAuthError("");
    if (!regEmail || !regName) { setAuthError("Bitte alle Felder ausfüllen."); return; }
    if (users[regEmail]) { setAuthError("E-Mail bereits registriert."); return; }
    const newUser = {
      email: regEmail,
      name: regName,
      id: genId(),
      streak: 0,
      tickets: 2,
      ticketsUsed: 0,
      lastTicketReset: today(),
      completedDays: [],
      totalWorkouts: 0,
      friends: [],
      followers: [],
      following: [],
      privacyPublic: true,
      favArea: null,
    };
    const u2 = { ...users, [regEmail]: newUser };
    saveUsers(u2);
    setUser(newUser);
    setScreen("app");
  };

  // ── Friends ──
  const addFriend = () => {
    setFriendError("");
    const found = Object.values(users).find((u) => u.id === friendId.toUpperCase());
    if (!found) { setFriendError("ID nicht gefunden."); return; }
    if (found.email === user.email) { setFriendError("Das bist du selbst 😄"); return; }
    if ((user.friends || []).includes(found.email)) { setFriendError("Bereits befreundet."); return; }
    updateUser({ friends: [...(user.friends || []), found.email] });
    setFriendId("");
  };

  const followUser = (targetEmail) => {
    const target = users[targetEmail];
    if (!target) return;
    const myFollowing = user.following || [];
    const theirFollowers = target.followers || [];
    if (!myFollowing.includes(targetEmail)) {
      updateUser({ following: [...myFollowing, targetEmail] });
      const updated = { ...target, followers: [...theirFollowers, user.email] };
      const u2 = { ...users, [targetEmail]: updated };
      saveUsers(u2);
    }
  };

  const handleFollowFromSettings = () => {
    const found = Object.values(users).find((u) => u.id === followId.toUpperCase());
    if (!found) return;
    followUser(found.email);
    setFollowId("");
  };

  // ── Feedback ──
  const openFeedback = async () => {
    setFeedbackOpen(true);
    setFeedbackLoading(true);
    const text = await getFeedback({
      streak: user.streak,
      totalWorkouts: user.totalWorkouts || 0,
      favArea: user.favArea,
      ticketsUsed: user.ticketsUsed || 0,
    });
    setFeedbackText(text);
    setFeedbackLoading(false);
  };

  // ── AI ──
  const askQuestion = async () => {
    if (!aiQ.trim()) return;
    setAiLoading(true);
    const ctx = workoutActive ? `Aktuelles Workout: ${wSteps[wIdx]?.name}` : "Kein aktives Workout";
    const answer = await askAI(aiQ, ctx);
    setAiA(answer);
    setAiLoading(false);
  };

  // ── Settings save ──
  const saveName = () => {
    if (editName.trim()) updateUser({ name: editName.trim() });
    setEditName("");
  };

  // ── Chat send ──
  const sendChat = () => {
    if (!chatMsg.trim()) return;
    const msg = { id: genId(), user: user.name, text: chatMsg, ts: Date.now() };
    setChatMsgs((m) => [...m, msg]);
    setChatMsg("");
  };

  // ── Calendar render ──
  const renderCalendar = () => {
    const days = getDaysInMonth(calYear, calMonth);
    const firstDay = new Date(calYear, calMonth, 1).getDay();
    const completed = new Set(
      (user?.completedDays || [])
        .filter((d) => {
          const dd = new Date(d);
          return dd.getFullYear() === calYear && dd.getMonth() === calMonth;
        })
        .map((d) => new Date(d).getDate())
    );
    const todayDate = new Date();
    const isCurrentMonth = todayDate.getFullYear() === calYear && todayDate.getMonth() === calMonth;
    const todayDay = isCurrentMonth ? todayDate.getDate() : -1;

    const cells = [];
    for (let i = 0; i < firstDay; i++) cells.push(<div key={`e${i}`} />);
    for (let d = 1; d <= days; d++) {
      const done = completed.has(d);
      const isToday = d === todayDay;
      cells.push(
        <div
          key={d}
          className={`
            aspect-square flex items-center justify-center rounded-xl text-sm font-semibold transition-all duration-300
            ${done ? "bg-orange-500 text-white shadow-lg shadow-orange-500/40 scale-110" : ""}
            ${isToday && !done ? "ring-2 ring-orange-400 text-orange-300" : ""}
            ${!done && !isToday ? (dark ? "text-white/50" : "text-gray-500") : ""}
          `}
        >
          {d}
        </div>
      );
    }
    const MONTHS = ["Jan","Feb","Mär","Apr","Mai","Jun","Jul","Aug","Sep","Okt","Nov","Dez"];
    return (
      <div className={`rounded-2xl p-4 ${glass()} mt-4`}>
        <div className="flex justify-between items-center mb-3">
          <button onClick={() => { if (calMonth === 0) { setCalMonth(11); setCalYear(y => y-1); } else setCalMonth(m => m-1); }} className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-white hover:bg-white/20">‹</button>
          <span className={`font-bold ${dark ? "text-white" : "text-gray-800"}`}>{MONTHS[calMonth]} {calYear}</span>
          <button onClick={() => { if (calMonth === 11) { setCalMonth(0); setCalYear(y => y+1); } else setCalMonth(m => m+1); }} className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-white hover:bg-white/20">›</button>
        </div>
        <div className="grid grid-cols-7 gap-1 text-center mb-1">
          {["So","Mo","Di","Mi","Do","Fr","Sa"].map(d => <div key={d} className="text-xs text-white/40 font-medium">{d}</div>)}
        </div>
        <div className="grid grid-cols-7 gap-1">{cells}</div>
      </div>
    );
  };

  // ── Colors ──
  const bg = dark
    ? "bg-gradient-to-br from-gray-950 via-gray-900 to-black"
    : "bg-gradient-to-br from-gray-50 via-white to-gray-100";
  const text = dark ? "text-white" : "text-gray-900";
  const subtext = dark ? "text-white/60" : "text-gray-500";
  const cardBg = dark ? glass() : "bg-white/70 backdrop-blur border border-gray-200/50 shadow-xl";

  // ════════════════════════════════════════════════════════════════
  // AUTH SCREENS
  // ════════════════════════════════════════════════════════════════
  if (screen === "login") return (
    <div className={`min-h-screen ${bg} flex flex-col items-center justify-center p-6 font-sans`}>
      <div className="w-full max-w-sm">
        <div className="text-center mb-10">
          <div className="text-5xl mb-3">🏋️</div>
          <h1 className="text-4xl font-black text-white tracking-tight">FitTastic</h1>
          <p className="text-white/50 mt-1 text-sm">Dein smarter Fitness-Begleiter</p>
        </div>
        <div className={`rounded-3xl p-6 ${glass()} space-y-4`}>
          <h2 className="text-white font-bold text-xl">Anmelden</h2>
          <input
            type="email" placeholder="E-Mail" value={email}
            onChange={e => setEmail(e.target.value)}
            className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-white/30 outline-none focus:ring-2 focus:ring-orange-400 transition"
          />
          {authError && <p className="text-red-400 text-sm">{authError}</p>}
          <button onClick={handleLogin} className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white font-bold py-3 rounded-xl hover:from-orange-400 hover:to-orange-500 active:scale-95 transition-all shadow-lg shadow-orange-500/30">
            Anmelden
          </button>
          <button onClick={() => { setScreen("register"); setAuthError(""); }} className="w-full text-white/50 text-sm hover:text-white transition">
            Noch kein Konto? Registrieren →
          </button>
        </div>
      </div>
    </div>
  );

  if (screen === "register") return (
    <div className={`min-h-screen ${bg} flex flex-col items-center justify-center p-6 font-sans`}>
      <div className="w-full max-w-sm">
        <div className="text-center mb-10">
          <div className="text-5xl mb-3">🏋️</div>
          <h1 className="text-4xl font-black text-white tracking-tight">FitTastic</h1>
          <p className="text-white/50 mt-1 text-sm">FitKonto erstellen</p>
        </div>
        <div className={`rounded-3xl p-6 ${glass()} space-y-4`}>
          <h2 className="text-white font-bold text-xl">Registrieren</h2>
          <input
            placeholder="Name" value={regName}
            onChange={e => setRegName(e.target.value)}
            className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-white/30 outline-none focus:ring-2 focus:ring-orange-400 transition"
          />
          <input
            type="email" placeholder="E-Mail" value={regEmail}
            onChange={e => setRegEmail(e.target.value)}
            className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-white/30 outline-none focus:ring-2 focus:ring-orange-400 transition"
          />
          {authError && <p className="text-red-400 text-sm">{authError}</p>}
          <button onClick={handleRegister} className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white font-bold py-3 rounded-xl hover:from-orange-400 hover:to-orange-500 active:scale-95 transition-all shadow-lg shadow-orange-500/30">
            FitKonto erstellen
          </button>
          <button onClick={() => { setScreen("login"); setAuthError(""); }} className="w-full text-white/50 text-sm hover:text-white transition">
            ← Zurück
          </button>
        </div>
      </div>
    </div>
  );

  if (!user) return null;

  // ════════════════════════════════════════════════════════════════
  // MAIN APP
  // ════════════════════════════════════════════════════════════════
  const tickets = user.tickets ?? 2;

  return (
    <div className={`min-h-screen ${bg} ${text} font-sans flex flex-col max-w-md mx-auto relative overflow-hidden`} style={{ minHeight: "100dvh" }}>

      {/* ── TOP BAR ── */}
      <div className={`flex items-center justify-between px-5 pt-12 pb-4 ${glass("sticky top-0 z-30")}`}>
        <div>
          <h1 className="text-xl font-black tracking-tight">
            <span className="text-orange-400">Fit</span>Tastic
          </h1>
          <p className={`text-xs ${subtext}`}>Hey, {user.name} 👋</p>
        </div>
        {/* Tickets */}
        <div className="flex items-center gap-2">
          {[0,1].map(i => (
            <div key={i} className={`text-lg transition-all duration-300 ${i < tickets ? "opacity-100 scale-110" : "opacity-20 grayscale"}`}>🎟️</div>
          ))}
        </div>
        {/* Feedback */}
        <button
          onClick={openFeedback}
          className={`w-10 h-10 rounded-xl ${glass()} flex items-center justify-center text-lg hover:scale-110 active:scale-95 transition-all`}
        >
          📊
        </button>
      </div>

      {/* ── CONTENT ── */}
      <div className="flex-1 overflow-y-auto px-4 pb-32 pt-2">

        {/* ══ WORKOUT TAB ══ */}
        {tab === "workout" && (
          <div className="space-y-4 animate-fade-in">

            {/* Prefs button */}
            <div className="flex justify-between items-center mt-2">
              <h2 className="text-lg font-bold">Dein Workout</h2>
              <button
                onClick={() => setShowPrefs(p => !p)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${cardBg} ${dark?"text-white":"text-gray-700"} flex items-center gap-1 hover:scale-105 transition`}
              >
                ⚙️ Personalisieren
              </button>
            </div>

            {/* Prefs panel */}
            {showPrefs && (
              <div className={`rounded-2xl p-5 ${cardBg} space-y-4 animate-slide-down`}>
                <h3 className="font-bold text-sm">Trainingsbereich wählen</h3>
                <div className="flex flex-wrap gap-2">
                  {Object.keys(WORKOUTS).map(area => (
                    <button
                      key={area}
                      onClick={() => setPrefs(p => ({
                        ...p,
                        areas: p.areas.includes(area) ? p.areas.filter(a => a !== area) : [...p.areas, area]
                      }))}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold capitalize transition-all active:scale-95 ${
                        prefs.areas.includes(area)
                          ? "bg-orange-500 text-white shadow-lg shadow-orange-500/30"
                          : dark ? "bg-white/10 text-white/70" : "bg-gray-100 text-gray-600"
                      }`}
                    >
                      {area === "chest" ? "💪 Brust" : area === "legs" ? "🦵 Beine" : area === "core" ? "🔥 Core" : area === "arms" ? "💪 Arme" : "🏋️ Rücken"}
                    </button>
                  ))}
                </div>
                <div>
                  <label className={`text-xs font-medium ${subtext}`}>Minuten pro Tag: {prefs.durationMin}</label>
                  <input type="range" min={5} max={60} value={prefs.durationMin}
                    onChange={e => setPrefs(p => ({ ...p, durationMin: +e.target.value }))}
                    className="w-full accent-orange-500 mt-1"
                  />
                </div>
                <div>
                  <label className={`text-xs font-medium ${subtext}`}>Tage pro Woche: {prefs.daysPerWeek}</label>
                  <input type="range" min={1} max={7} value={prefs.daysPerWeek}
                    onChange={e => setPrefs(p => ({ ...p, daysPerWeek: +e.target.value }))}
                    className="w-full accent-orange-500 mt-1"
                  />
                </div>
              </div>
            )}

            {/* Calendar */}
            {renderCalendar()}

            {/* Stats row */}
            <div className="grid grid-cols-3 gap-3 mt-4">
              {[
                { label: "Streak", value: `${user.streak}🔥`, color: "text-orange-400" },
                { label: "Workouts", value: user.totalWorkouts || 0, color: "text-green-400" },
                { label: "Tickets", value: `${tickets}/2 🎟️`, color: "text-purple-400" },
              ].map(s => (
                <div key={s.label} className={`rounded-2xl p-3 text-center ${cardBg}`}>
                  <div className={`text-xl font-black ${s.color}`}>{s.value}</div>
                  <div className={`text-xs ${subtext} mt-0.5`}>{s.label}</div>
                </div>
              ))}
            </div>

            {/* Workout Active */}
            {workoutActive ? (
              <div className={`rounded-2xl p-5 ${cardBg} space-y-4`}>
                <div className="flex justify-between items-center">
                  <h3 className="font-bold">Workout läuft</h3>
                  <button onClick={stopWorkout} className="px-3 py-1.5 bg-red-500/20 text-red-400 rounded-xl text-xs font-semibold border border-red-500/30 hover:bg-red-500/30 transition active:scale-95">
                    Stop ⛔
                  </button>
                </div>
                {/* Progress */}
                <div className="flex justify-between text-xs text-white/40">
                  <span>Schritt {wIdx + 1} / {wSteps.length}</span>
                </div>
                <div className="w-full bg-white/10 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-orange-400 to-orange-600 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${((wIdx) / wSteps.length) * 100}%` }}
                  />
                </div>
                {/* Current step */}
                <div className={`rounded-xl p-4 text-center ${wSteps[wIdx]?.type === "rest" ? "bg-blue-500/20 border border-blue-400/30" : "bg-orange-500/20 border border-orange-400/30"}`}>
                  <div className="text-3xl mb-1">{wSteps[wIdx]?.type === "rest" ? "😮‍💨" : "🔥"}</div>
                  <div className="font-bold text-lg">{wSteps[wIdx]?.name}</div>
                  <div className={`text-4xl font-black mt-2 ${wSteps[wIdx]?.type === "rest" ? "text-blue-400" : "text-orange-400"}`}>{wTimer}s</div>
                </div>
                {/* Controls */}
                <div className="flex gap-3">
                  <button
                    onClick={() => setWPaused(p => !p)}
                    className={`flex-1 py-3 rounded-xl font-bold text-sm transition active:scale-95 ${wPaused ? "bg-orange-500 text-white" : "bg-white/10 text-white"}`}
                  >
                    {wPaused ? "▶ Weiter" : "⏸ Pause"}
                  </button>
                </div>
                {/* AI Helper */}
                <button
                  onClick={() => setAiOpen(true)}
                  className="w-full py-2.5 rounded-xl bg-purple-500/20 border border-purple-400/30 text-purple-300 text-sm font-semibold hover:bg-purple-500/30 transition active:scale-95"
                >
                  🤖 KI fragen
                </button>
              </div>
            ) : (
              <button
                onClick={startWorkout}
                disabled={tickets <= 0}
                className={`w-full py-5 rounded-2xl font-black text-lg transition-all active:scale-95 shadow-2xl mt-2 ${
                  tickets > 0
                    ? "bg-gradient-to-r from-orange-500 to-orange-600 text-white hover:from-orange-400 hover:to-orange-500 shadow-orange-500/40"
                    : "bg-gray-700 text-gray-500 cursor-not-allowed"
                }`}
              >
                {tickets > 0 ? "⚡ Workout starten" : "Keine Tickets (reset um 0 Uhr)"}
              </button>
            )}
          </div>
        )}

        {/* ══ FRIENDS TAB ══ */}
        {tab === "friends" && (
          <div className="space-y-4 animate-fade-in mt-2">
            <h2 className="text-lg font-bold">Freunde</h2>
            <div className={`rounded-2xl p-4 ${cardBg} space-y-3`}>
              <p className={`text-xs font-semibold ${subtext}`}>Deine FitKonto-ID</p>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-orange-500/20 border border-orange-400/30 rounded-xl px-4 py-2 font-mono font-bold text-orange-400 text-center tracking-widest">
                  {user.id}
                </div>
                <button
                  onClick={() => navigator.clipboard?.writeText(user.id)}
                  className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-sm hover:bg-white/20 transition"
                >📋</button>
              </div>
            </div>

            <div className={`rounded-2xl p-4 ${cardBg} space-y-3`}>
              <p className={`text-xs font-semibold ${subtext}`}>Freund per ID hinzufügen</p>
              <div className="flex gap-2">
                <input
                  placeholder="ID eingeben" value={friendId}
                  onChange={e => setFriendId(e.target.value.toUpperCase())}
                  className="flex-1 bg-white/10 border border-white/20 rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-orange-400 uppercase placeholder-white/20 transition"
                />
                <button onClick={addFriend} className="px-4 py-2 bg-orange-500 text-white rounded-xl text-sm font-bold hover:bg-orange-400 active:scale-95 transition">
                  +
                </button>
              </div>
              {friendError && <p className="text-red-400 text-xs">{friendError}</p>}
            </div>

            {/* Friend list */}
            <div className="space-y-2">
              {(user.friends || []).length === 0 && (
                <div className={`rounded-2xl p-6 text-center ${cardBg} ${subtext}`}>
                  <div className="text-3xl mb-2">👥</div>
                  <p className="text-sm">Noch keine Freunde. Füge sie per ID hinzu!</p>
                </div>
              )}
              {(user.friends || []).map(email => {
                const f = users[email];
                if (!f) return null;
                return (
                  <div key={email} className={`rounded-2xl p-4 ${cardBg} flex items-center justify-between`}>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center font-bold text-white">
                        {f.name[0]}
                      </div>
                      <div>
                        <div className="font-bold text-sm">{f.name}</div>
                        <div className={`text-xs ${subtext}`}>🔥 {f.streak} Streak</div>
                      </div>
                    </div>
                    <button
                      onClick={() => setViewingFriend(f)}
                      className="px-3 py-1.5 bg-white/10 rounded-xl text-xs hover:bg-white/20 transition active:scale-95"
                    >
                      Profil
                    </button>
                  </div>
                );
              })}
            </div>

            {/* Friend profile modal */}
            {viewingFriend && (
              <div className="fixed inset-0 z-50 flex items-end justify-center p-4" onClick={() => setViewingFriend(null)}>
                <div className={`w-full max-w-sm rounded-3xl p-6 ${glassDark()} space-y-4`} onClick={e => e.stopPropagation()}>
                  <div className="flex justify-between">
                    <h3 className="font-bold text-lg text-white">{viewingFriend.name}</h3>
                    <button onClick={() => setViewingFriend(null)} className="text-white/40 hover:text-white">✕</button>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { label: "ID", value: viewingFriend.id },
                      { label: "Streak", value: `${viewingFriend.streak} 🔥` },
                      { label: "Workouts", value: viewingFriend.totalWorkouts || 0 },
                      { label: "Follower", value: (viewingFriend.followers || []).length },
                    ].map(s => (
                      <div key={s.label} className="bg-white/10 rounded-xl p-3 text-center">
                        <div className="text-white font-bold">{s.value}</div>
                        <div className="text-white/40 text-xs">{s.label}</div>
                      </div>
                    ))}
                  </div>
                  {viewingFriend.favArea && (
                    <div className="bg-orange-500/20 rounded-xl p-3 text-center border border-orange-400/30">
                      <span className="text-orange-300 text-sm font-semibold">
                        Lieblingsbereich: {viewingFriend.favArea}
                      </span>
                    </div>
                  )}
                  <button
                    onClick={() => { followUser(viewingFriend.email); setViewingFriend(null); }}
                    className="w-full py-3 bg-orange-500 text-white rounded-xl font-bold text-sm hover:bg-orange-400 active:scale-95 transition"
                  >
                    Folgen
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══ STREAK TAB ══ */}
        {tab === "streak" && (
          <div className="space-y-4 animate-fade-in mt-2">
            <h2 className="text-lg font-bold">Dein Streak</h2>
            <div className={`rounded-2xl p-6 text-center ${cardBg}`}>
              <div className="text-7xl font-black text-orange-400 mb-1">{user.streak}</div>
              <div className={`text-sm ${subtext}`}>Tage in Folge</div>
              <div className="text-4xl mt-3">🔥</div>
            </div>
            {/* Streak milestones */}
            <div className="space-y-2">
              {[
                { days: 3, label: "Warm-Up", emoji: "🌱" },
                { days: 7, label: "Woche geschafft!", emoji: "⭐" },
                { days: 14, label: "Zwei Wochen Profi", emoji: "🏆" },
                { days: 30, label: "Ein Monat Legend", emoji: "🥇" },
                { days: 100, label: "100 Tage Elite", emoji: "👑" },
              ].map(m => (
                <div key={m.days} className={`rounded-xl p-3 flex items-center gap-3 ${cardBg} ${user.streak >= m.days ? "ring-1 ring-orange-400/50" : "opacity-50"}`}>
                  <div className="text-2xl">{m.emoji}</div>
                  <div>
                    <div className={`font-semibold text-sm ${user.streak >= m.days ? "" : subtext}`}>{m.label}</div>
                    <div className={`text-xs ${subtext}`}>{m.days} Tage</div>
                  </div>
                  {user.streak >= m.days && <div className="ml-auto text-orange-400 text-lg">✓</div>}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ══ RANG TAB (global chat) ══ */}
        {tab === "rang" && (
          <div className="space-y-4 animate-fade-in mt-2 flex flex-col" style={{ minHeight: "70vh" }}>
            <h2 className="text-lg font-bold">Globaler Chat 🌍</h2>
            {/* Rang board */}
            <div className={`rounded-2xl p-4 ${cardBg}`}>
              <h3 className={`text-xs font-bold ${subtext} mb-3 uppercase tracking-widest`}>Top Streaks</h3>
              {Object.values(users).sort((a,b) => (b.streak||0) - (a.streak||0)).slice(0,5).map((u,i) => (
                <div key={u.email} className={`flex items-center gap-3 py-2 ${i < 4 ? "border-b border-white/5" : ""}`}>
                  <span className={`text-sm font-black w-5 ${i===0?"text-yellow-400":i===1?"text-gray-300":i===2?"text-amber-600":subtext}`}>
                    {i+1}
                  </span>
                  <div className="w-7 h-7 rounded-lg bg-orange-500/30 flex items-center justify-center text-xs font-bold">{u.name[0]}</div>
                  <span className="text-sm font-semibold flex-1">{u.name}</span>
                  <span className="text-orange-400 text-sm font-bold">{u.streak}🔥</span>
                </div>
              ))}
            </div>

            {/* Chat */}
            <div className={`rounded-2xl p-4 ${cardBg} flex-1 flex flex-col`}>
              <div className="flex-1 overflow-y-auto space-y-2 max-h-64 mb-3">
                {chatMsgs.map(m => (
                  <div key={m.id} className={`flex gap-2 ${m.user === user.name ? "flex-row-reverse" : ""}`}>
                    <div className="w-7 h-7 rounded-lg bg-orange-500/30 flex items-center justify-center text-xs font-bold flex-shrink-0">{m.user[0]}</div>
                    <div className={`max-w-[75%] rounded-xl px-3 py-2 text-sm ${m.user === user.name ? "bg-orange-500 text-white" : dark ? "bg-white/10 text-white" : "bg-gray-100 text-gray-800"}`}>
                      <div className={`text-xs mb-0.5 font-bold ${m.user === user.name ? "text-orange-200" : "text-orange-400"}`}>{m.user}</div>
                      {m.text}
                    </div>
                  </div>
                ))}
                <div ref={chatEndRef} />
              </div>
              <div className="flex gap-2">
                <input
                  placeholder="Nachricht..." value={chatMsg}
                  onChange={e => setChatMsg(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && sendChat()}
                  className="flex-1 bg-white/10 border border-white/20 rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-orange-400 transition"
                />
                <button onClick={sendChat} className="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center hover:bg-orange-400 active:scale-95 transition">
                  ➤
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ══ SETTINGS TAB ══ */}
        {tab === "settings" && (
          <div className="space-y-4 animate-fade-in mt-2">
            <h2 className="text-lg font-bold">Einstellungen</h2>

            {/* Account */}
            <div className={`rounded-2xl p-4 ${cardBg} space-y-3`}>
              <h3 className="font-bold text-sm text-orange-400">👤 Konto</h3>
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center text-2xl font-black text-white">
                  {user.name[0]}
                </div>
                <div>
                  <div className="font-bold">{user.name}</div>
                  <div className={`text-xs ${subtext}`}>{user.email}</div>
                  <div className={`text-xs font-mono text-orange-400`}>ID: {user.id}</div>
                </div>
              </div>
              <div className="flex gap-2">
                <input
                  placeholder="Neuer Name" value={editName}
                  onChange={e => setEditName(e.target.value)}
                  className="flex-1 bg-white/10 border border-white/20 rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-orange-400 transition"
                />
                <button onClick={saveName} className="px-4 py-2 bg-orange-500 text-white rounded-xl text-sm font-bold hover:bg-orange-400 active:scale-95 transition">
                  Speichern
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2 text-center">
                <div className="bg-white/5 rounded-xl p-2">
                  <div className="font-bold text-orange-400">{(user.following||[]).length}</div>
                  <div className={`text-xs ${subtext}`}>Folge ich</div>
                </div>
                <div className="bg-white/5 rounded-xl p-2">
                  <div className="font-bold text-orange-400">{(user.followers||[]).length}</div>
                  <div className={`text-xs ${subtext}`}>Follower</div>
                </div>
              </div>
            </div>

            {/* Follow */}
            <div className={`rounded-2xl p-4 ${cardBg} space-y-3`}>
              <h3 className="font-bold text-sm text-orange-400">➕ Jemandem folgen</h3>
              <div className="flex gap-2">
                <input
                  placeholder="ID eingeben" value={followId}
                  onChange={e => setFollowId(e.target.value.toUpperCase())}
                  className="flex-1 bg-white/10 border border-white/20 rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-orange-400 uppercase placeholder-white/20 transition"
                />
                <button onClick={handleFollowFromSettings} className="px-4 py-2 bg-orange-500 text-white rounded-xl text-sm font-bold hover:bg-orange-400 active:scale-95 transition">
                  Folgen
                </button>
              </div>
            </div>

            {/* Privacy */}
            <div className={`rounded-2xl p-4 ${cardBg} space-y-3`}>
              <h3 className="font-bold text-sm text-orange-400">🔒 Privatsphäre</h3>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-semibold">Profil öffentlich</div>
                  <div className={`text-xs ${subtext}`}>Andere können dein Profil sehen</div>
                </div>
                <button
                  onClick={() => { const v = !privacyPublic; setPrivacyPublic(v); updateUser({ privacyPublic: v }); }}
                  className={`w-12 h-6 rounded-full transition-all ${privacyPublic ? "bg-orange-500" : "bg-white/20"} relative`}
                >
                  <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-all ${privacyPublic ? "right-0.5" : "left-0.5"}`} />
                </button>
              </div>
            </div>

            {/* Theme */}
            <div className={`rounded-2xl p-4 ${cardBg} space-y-3`}>
              <h3 className="font-bold text-sm text-orange-400">🎨 Erscheinungsbild</h3>
              <div className="flex gap-3">
                {[
                  { label: "🌙 Dunkel", val: true },
                  { label: "☀️ Hell", val: false },
                ].map(o => (
                  <button
                    key={String(o.val)}
                    onClick={() => setDark(o.val)}
                    className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition active:scale-95 ${dark === o.val ? "bg-orange-500 text-white shadow-lg shadow-orange-500/30" : "bg-white/10 " + subtext}`}
                  >
                    {o.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Logout */}
            <button
              onClick={() => { setUser(null); setScreen("login"); setEmail(""); }}
              className="w-full py-3 rounded-2xl bg-red-500/20 border border-red-400/30 text-red-400 font-bold text-sm hover:bg-red-500/30 transition active:scale-95"
            >
              Abmelden
            </button>

            {/* Credits */}
            <div className={`rounded-2xl p-5 ${cardBg} overflow-hidden`}>
              <h3 className="font-bold text-sm text-orange-400 mb-4 text-center uppercase tracking-widest">Mitwirkende</h3>
              <div className="relative overflow-hidden" style={{ height: "180px" }}>
                <div className="animate-credits text-center space-y-3">
                  <div>
                    <p className={`text-xs ${subtext} uppercase tracking-widest`}>Erfinder</p>
                    <p className="font-black text-lg text-orange-400">Toni</p>
                  </div>
                  <div>
                    <p className={`text-xs ${subtext} uppercase tracking-widest`}>Idee</p>
                    <p className="font-black text-lg text-orange-400">Toni</p>
                  </div>
                  <div className="pt-2">
                    <p className={`text-xs ${subtext} uppercase tracking-widest`}>In Kooperation mit</p>
                    <p className="font-bold text-white text-base mt-1">FitFlow</p>
                    <p className={`text-xs ${subtext}`}>Official Partner</p>
                  </div>
                  <div>
                    <p className={`text-xs ${subtext} uppercase tracking-widest`}>Powered by</p>
                    <p className="font-bold text-white text-sm">FitFlow Technologies</p>
                  </div>
                  <div>
                    <p className={`text-xs ${subtext} uppercase tracking-widest`}>Design Partnerschaft</p>
                    <p className="font-bold text-white text-sm">FitFlow Creative Studio</p>
                  </div>
                  <div className="pt-4">
                    <p className={`text-xs ${subtext}`}>© 2025 FitTastic · All rights reserved</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ── BOTTOM NAV (Liquid Glass) ── */}
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md px-4 pb-6 z-20">
        <div className={`rounded-3xl ${glassDark()} p-2 flex justify-around`}>
          {[
            { id: "workout", icon: "🏋️", label: "Workout" },
            { id: "friends", icon: "👥", label: "Freunde" },
            { id: "streak", icon: "🔥", label: "Streak" },
            { id: "rang", icon: "🌍", label: "Rang" },
            { id: "settings", icon: "⚙️", label: "Settings" },
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex flex-col items-center gap-1 px-3 py-2 rounded-2xl transition-all duration-200 active:scale-90 ${
                tab === t.id
                  ? "bg-orange-500/30 scale-110 shadow-lg shadow-orange-500/20"
                  : "hover:bg-white/10"
              }`}
            >
              <span className="text-xl">{t.icon}</span>
              <span className={`text-[10px] font-semibold ${tab === t.id ? "text-orange-400" : "text-white/50"}`}>
                {t.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* ── FEEDBACK MODAL ── */}
      {feedbackOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => setFeedbackOpen(false)}>
          <div className={`w-full max-w-sm rounded-3xl p-6 ${glassDark()} space-y-4`} onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-white text-lg">📊 Dein Feedback</h3>
              <button onClick={() => setFeedbackOpen(false)} className="text-white/40 hover:text-white text-lg">✕</button>
            </div>
            {feedbackLoading ? (
              <div className="flex flex-col items-center py-8 gap-3">
                <div className="w-8 h-8 border-2 border-orange-400 border-t-transparent rounded-full animate-spin" />
                <p className="text-white/50 text-sm">KI analysiert deine Daten...</p>
              </div>
            ) : (
              <div className="bg-orange-500/10 border border-orange-400/20 rounded-2xl p-4">
                <p className="text-white/90 text-sm leading-relaxed">{feedbackText}</p>
              </div>
            )}
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: "Streak", value: `${user.streak}🔥` },
                { label: "Workouts", value: user.totalWorkouts || 0 },
                { label: "Tickets used", value: user.ticketsUsed || 0 },
                { label: "Bereich", value: user.favArea || "—" },
              ].map(s => (
                <div key={s.label} className="bg-white/5 rounded-xl p-2 text-center">
                  <div className="text-orange-400 font-bold text-sm">{s.value}</div>
                  <div className="text-white/40 text-xs">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── AI MODAL ── */}
      {aiOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => setAiOpen(false)}>
          <div className={`w-full max-w-sm rounded-3xl p-6 ${glassDark()} space-y-4`} onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-white text-lg">🤖 KI-Assistent</h3>
              <button onClick={() => setAiOpen(false)} className="text-white/40 hover:text-white text-lg">✕</button>
            </div>
            {workoutActive && (
              <div className="bg-orange-500/20 rounded-xl px-3 py-2 text-orange-300 text-xs font-medium">
                Aktuell: {wSteps[wIdx]?.name}
              </div>
            )}
            <div className="flex gap-2">
              <input
                placeholder="Frage stellen..." value={aiQ}
                onChange={e => setAiQ(e.target.value)}
                onKeyDown={e => e.key === "Enter" && askQuestion()}
                className="flex-1 bg-white/10 border border-white/20 rounded-xl px-3 py-2 text-sm text-white placeholder-white/30 outline-none focus:ring-2 focus:ring-purple-400 transition"
              />
              <button
                onClick={askQuestion} disabled={aiLoading}
                className="w-10 h-10 bg-purple-500 rounded-xl flex items-center justify-center hover:bg-purple-400 active:scale-95 transition disabled:opacity-50"
              >
                {aiLoading ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : "➤"}
              </button>
            </div>
            {aiA && (
              <div className="bg-purple-500/10 border border-purple-400/20 rounded-2xl p-4">
                <p className="text-white/90 text-sm leading-relaxed">{aiA}</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── CSS ANIMATIONS ── */}
      <style>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes slide-down {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes credits {
          0% { transform: translateY(100%); }
          100% { transform: translateY(-100%); }
        }
        .animate-fade-in { animation: fade-in 0.35s ease both; }
        .animate-slide-down { animation: slide-down 0.3s ease both; }
        .animate-credits { animation: credits 18s linear infinite; }
      `}</style>
    </div>
  );
}
