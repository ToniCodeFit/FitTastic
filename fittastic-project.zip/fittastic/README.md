# 🏋️ FitTastic

Dein smarter Fitness-Begleiter.

---

## 🚀 Deployment auf Vercel (5 Minuten)

### Schritt 1 – GitHub
1. Gehe auf **github.com** → neuen Account erstellen (kostenlos)
2. Klicke auf **"New repository"** → Name: `fittastic` → Public → **Create**
3. Lade alle Dateien aus diesem ZIP hoch (Drag & Drop auf die Seite)

### Schritt 2 – Vercel
1. Gehe auf **vercel.com** → mit GitHub einloggen
2. Klicke **"Add New Project"**
3. Wähle dein `fittastic` Repository aus
4. Klicke **"Deploy"** – fertig!

✅ Deine App ist jetzt unter `fittastic.vercel.app` erreichbar!

### Link anpassen
In Vercel unter **Settings → Domains** kannst du den Namen ändern, z.B. zu `meine-fittastic-app.vercel.app`

---

## 💡 Features
- 🔐 Login & Registrierung mit FitKonto-ID
- 🏋️ Personalisierte Workouts mit Timer
- 📅 Kalender mit Fortschritt
- 🔥 Streak-System
- 🎟️ Ticket-System (wie Duolingo)
- 👥 Freunde per ID hinzufügen
- 🌍 Globaler Chat & Rangliste
- 🤖 KI-Assistent & Feedback
- ⚙️ Einstellungen mit Credits

---

Erfinder: Toni | Idee: Toni | Kooperation: FitFlow
